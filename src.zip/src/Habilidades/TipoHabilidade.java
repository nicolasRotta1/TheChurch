package Habilidades; public enum TipoHabilidade{
    PRIMARIA,
    SECUNDARIA,
    ESPECIAL,
    CURA,
    BUFF,
    DEBUFF
}
