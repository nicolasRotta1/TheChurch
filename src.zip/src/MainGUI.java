import gui.JogoConsole;

public class MainGUI {
    public static void main(String[] args) {
        // Inicia o jogo com interface melhorada
        new JogoConsole().iniciar();
    }
}
