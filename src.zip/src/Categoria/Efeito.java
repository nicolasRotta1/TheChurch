package Categoria;
public interface Efeito {
    String getTag();
    double getMultiplicador();
    String getDescricao();
}
